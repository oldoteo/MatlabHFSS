%hfssgetFaceIDsFromModel return the list of faceIDs of a body by its name
function faceIDs=hfssgetFaceIDsFromModel(oEditor,bodyNameStr)
faceIDs = oEditor.GetFaceIDs(bodyNameStr);