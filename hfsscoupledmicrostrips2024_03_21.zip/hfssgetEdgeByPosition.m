%hfssgetEdgeByPosition Get edge (edgeId) from its part and a point x,y,z
%
%BEWARE: the coordinates in Ansys<2018 are expressed always in the global
%coordinate system.
%From Ansys 2018, instead, the coordinates must be expressed in the current
%coordinate system.
%Thus:
%            if vers<2018
%                %%In Ansys 2017 regardless of the active Coordinate system,
%                %%getEdgeByPosition worked using global coordinates
%                eid=getEdgeByPosition(oEditor,phShifterNameStr,currentX,(0),(0));
%            else
%                %%In Ansys 2019 getEdgeByPosition works on the active coordinate
%                %%system
%                eid=getEdgeByPosition(oEditor,phShifterNameStr,phaseShiftersWL_m(n,2),(0),(0));
%            end
%
%SEE ALSO hfssgetFaceIDsFromModel
function eID=hfssgetEdgeByPosition(oEditor,partNameStr,x,y,z)



eID=oEditor.GetEdgeByPosition(...
    {'NAME:EdgeParameters',...
        'BodyName:=', partNameStr,...
        'XPosition:=', hfssmmStr(x), 'YPosition:=', hfssmmStr(y), 'ZPosition:=', hfssmmStr(z)...
    }...
);