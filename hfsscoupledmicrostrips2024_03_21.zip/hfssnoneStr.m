%hfssnoneStr Return a string expressing the given number
%If a string is already passed, it is not modified, merely returned.
%If a number is provided, it is assumed to be a unitless number, which is then
% converted to an Ansys format string (xyz)
%SEE ALSO hfssnoneStr, hfssGHzStr, hfssmmStr
function s=hfssnoneStr(v)
if ischar(v)
    s=v;
else
    s=[num2str(v,8) ''];
end