%hfssGHzStr Return a string expressing the given frequency (in Hz) in GHz
%If a string is already passed, it is not modified, merely returned.
%If a number is provided, it is assumed to be a frequency in Hz, which is then
%converted to GHz and converted to an Ansys format string (xyzGHz)
%SEE ALSO hfssmmStr, hfssnoneStr, hfssGHzStr
function s=hfssGHzStr(f_Hz)
if ischar(f_Hz)
    s=f_Hz;
else
    s=[num2str(f_Hz/1e9,8) 'GHz'];
end