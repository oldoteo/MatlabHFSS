%hfssgetObjectIDByName get object (objectId) from its name
%
function oID=hfssgetObjectIDByName(oEditor,nameStr)
oID = oEditor.GetObjectIDByName(nameStr);