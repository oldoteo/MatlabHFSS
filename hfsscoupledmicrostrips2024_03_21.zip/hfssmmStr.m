%hfssmmStr Return a string expressing the given length (in m) in mm
%If a string is already passed, it is not modified, merely returned.
%If a number is provided, it is assumed to be a length in m, which is then
%converted to mm and converted to an Ansys format string (xyzmm)
%SEE ALSO hfssmmStr, hfssnoneStr, hfssGHzStr
function s=hfssmmStr(l_m)
if ischar(l_m)
    s=l_m;
else
    s=[num2str(l_m/1e-3,8) 'mm'];
end