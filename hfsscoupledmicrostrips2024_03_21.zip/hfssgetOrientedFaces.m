%hfssgetOrientedFaces Return the faceId of extreme faces xmin,xmax,ymin...
%
%[facexmin,facexmax,faceymin,faceymax,facezmin,facezmax]=hfssgetOrientedFaces(oEditor,bodyname)
%
%CHANGELOG
%   06/01/2023: created by Matteo Oldoni
%
function [facexmin,facexmax,faceymin,faceymax,facezmin,facezmax]=hfssgetOrientedFaces(oEditor,bodyname)
faces=hfssgetFaceIDsFromModel(oEditor,bodyname);
minZ=Inf;
maxZ=-Inf;
minX=Inf;
maxX=-Inf;
minY=Inf;
maxY=-Inf;
facezmin=[];
for ii=1:numel(faces)
    faces{ii}=str2double(faces{ii});
    [x,y,z]=hfssgetFaceCenter(oEditor,faces{ii});
    if x<minX
        facexmin=(faces{ii});
        minX=x;
    end
    if x>maxX
        facexmax=faces{ii};
        maxX=x;
    end    
    if y<minY
        faceymin=(faces{ii});
        minY=y;
    end
    if y>maxY
        faceymax=faces{ii};
        maxY=y;
    end    
    if z<minZ
        facezmin=(faces{ii});
        minZ=z;
    end
    if z>maxZ
        facezmax=faces{ii};
        maxZ=z;
    end
end