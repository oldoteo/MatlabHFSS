%hfssgetFaceCenter Get x,y,z in meters of the center of a face (faceId)
%
%SEE ALSO hfssgetFaceIDsFromModel
function [x_m,y_m,z_m]=hfssgetFaceCenter(oEditor,faceID)
oFaceCenter = oEditor.GetFaceCenter(faceID);
unit=oEditor.GetModelUnits();
switch unit
    case 'um'
        multiplier=1e-6;
    case 'mm'
        multiplier=1e-3;
    case 'm'
        multiplier=1e-0;
    case 'km'
        multiplier=1e3;
end
x_m=str2double(oFaceCenter{1})*multiplier;
y_m=str2double(oFaceCenter{2})*multiplier;
z_m=str2double(oFaceCenter{3})*multiplier;