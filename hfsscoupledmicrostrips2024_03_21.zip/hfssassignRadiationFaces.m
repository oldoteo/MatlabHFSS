%hfssassignRadiationFaces Assign the given face IDs as radiation boundaries
%
%   hfssassignRadiationFaces(oDesign,facesID,radNameStr)
%SEE ALSO hfssgetOrientedFaces, hfssgetFaceByPosition, hfssgetFacesByModel
%CHANGELOG
%   06/01/2024: created by Matteo Oldoni
function hfssassignRadiationFaces(oDesign,facesID,radNameStr)
if nargin<3
    radNameStr='RadBoundary';
end
oModule = oDesign.GetModule('BoundarySetup');
oModule.AssignRadiation({['NAME:' radNameStr], 'Faces:=',num2cell(facesID), 'IsFssReference:=', false, 'IsForPML:=', false});
