%hfsscoupledmicrostrips
%  A script to create an arrangement of microstrips with gaps, offsets and
%  varying width. The design is drawn in HFSS and entirely parametrized
%  with Design Variables for further tweaking without Matlab.
%
%The substrate is described by its material name and height (dielName, subsH_m)
%The conductor is described by its name and thickness (metalName, metalThick_m)
%
%dielName and metalName MUST BE correct material names in HFSS (either
%predefined in the standard material list or already user defined in the same project).
%
%Then each section of microstrip is defined by one row in WLGS_m:
%Each row in WLGO_m is as follows (all in meters)
%[width (along y), 
%    length (along x), 
%       gap (along x, between the first edge of the new line and the last end edge 
%       of the preceding line)
%         offset (along y, distance between the center lines of the new and
%         previous line)]
%Specify gap=0 and offset=0 to have a continuous line (a step in width for
% instance)
%Specify gap>0 and offset=0 to have two end-coupled lines
%Specify gap<0 and offset>(width_previous/2+width_current/2) to have
% edge-coupled microstrips
%Ports are added at 0,0 and at the second edge of the last line.
%A substrate is added, extending to the left and right of the provided
%structure (also entirely parametrized to adjust automatically when the
%traces are changed), with a ground layer below (but no air below gnd).
%An airbox is created on top.
%
%Microstrips have length along x and width along y and thickness along z.
%The dielectric is for z<0 while microstrips are placed from z=0

if 1==1
    dielName='Vacuum'; %Material for the substrate (case sensitive!)
    subsH_m=1e-3;      %Thickness of the substrate
    metalName='copper'; %Material of all metal traces (top and ground)
    metalThick_m=35e-6; %Thickness of all metal traces (top and ground)
    hfssprj=['test_' datestr(now,'yyyymmdd_hhMMss')]; %Project name (it must not already exist in the current design in HFSS)
    WLGO_m=[3e-3,  2e-2,  0,     0; ... %Input line
            2e-3,  1.5e-2,0,     0; ... %Step in width, no gap no offset
            1.5e-3 2e-2   0.2e-3 0; ... %A gap between to aligned microstrips
            2e-3 4e-2, -1e-2 3e-3]; ... %Edge coupled-microstrip
    %OTHER PARAMETERS
    borderYMin_m=1e-2;  %Border at left and right (the substrate will extend beyond the traces by this amount)
    borderYMax_m=2e-2;
    airThick_m=3e-2;    %Thickness of the air on top
    portwidth_m=6e-3;   %Width of the two ports
    portheightabove=4e-3;  %Height of the two ports above the substrate (below the ports automatically reach down to touch gnd)
    frequencyCenter_Hz=20e9; %Frequency of analysis and center of the freq. sweep
    frequencySpan_Hz=1e9; %Frequency sweep (half on each side of the center)
    maxDeltaS=0.02;  %deltaS for convergence
    Nfreqpoints=101; %Number of frequency points for interpolated sweep
elseif 1==1
    dielName='alumina_96pct'; %Material for the substrate (case sensitive!)
    subsH_m=101e-6;      %Thickness of the substrate
    metalName='pec'; %Material of all metal traces (top and ground)
    metalThick_m=3e-6; %Thickness of all metal traces (top and ground)
    hfssprj=['test_' datestr(now,'yyyymmdd_hhMMss')]; %Project name (it must not already exist in the current design in HFSS)
    WLGO_m=[98.6934e-6,  102e-6+387.27e-6,  0,     0; ... %Input line
            98.6917e-6,  363.7e-6, 0, 0; ... %coupled line
            98.6917e-6   363.7e-6  -363.7e-6 26.61e-6+1j; ... %First resonator, half
            98.6917e-6   351.0e-6  0 0; ... %First resonator, half
            98.6917e-6   351.0e-6  -351.0e-6 177.4e-6+1j; ... %Second resonator half
            98.6917e-6   353.7e-6  0 0; ... %Second resonator half
            98.6917e-6   353.7e-6  -353.7e-6 220.6e-6+1j; ... %Third resonator, half
            98.6917e-6   353.7e-6  0  0;... %Third resonator, half
            98.6917e-6   353.7e-6  -353.7e-6 220.6e-6+1j; ... %Fourth resonator half
            98.6917e-6   351.0e-6  0 0; ... %Fourth resonator half
            98.6917e-6   351.0e-6  -351.0e-6 177.4e-6+1j; ... %Fifth resonator, half
            98.6917e-6   363.7e-6  0 0; ... %Fifth resonator, half
            98.6917e-6   363.7e-6  -363.7e-6 26.61e-6+1j; ... %Coupled line
            98.6934e-6,  102e-6+387.27e-6,  0,     0; ... %Output line
            ];
    %OTHER PARAMETERS
    borderYMin_m=1e-3;  %Border at left and right (the substrate will extend beyond the traces by this amount)
    borderYMax_m=1e-3;
    airThick_m=1.5e-3;    %Thickness of the air on top
    portwidth_m=1e-3;   %Width of the two ports
    portheightabove=0.4e-3;  %Height of the two ports above the substrate (below the ports automatically reach down to touch gnd)
    frequencyCenter_Hz=75e9; %Frequency of analysis and center of the freq. sweep
    frequencySpan_Hz=14e9; %Frequency sweep (half on each side of the center)
    maxDeltaS=0.02;  %deltaS for convergence
    Nfreqpoints=101; %Number of frequency points for interpolated sweep

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%NO MORE PARAMETERS BELOW, ONLY CODE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[hfss, oDesktop, oProject, oDesign,vers,oEditor]=hfssopen('',hfssprj,''); %Open a new project with the given name
%Start from the global reference system, create the block starting from
%that reference system and then create a reference system at the opposite
%end of the microstrip

metalThicknessVar=['_MetalThickness'];
hfsscreateVariableMm(oDesign,metalThicknessVar,metalThick_m);


csName=''; %Used to set the reference system of each shape
minX_m=Inf; maxX_m=-Inf; minY_m=Inf; maxY_m=-Inf;
currentX_m=0;
currentY_m=0;
currentX_str='';
currentY_str='';
minX_str='';
maxX_str='';
minY_str='';
maxY_str='';
previouswidthCurrent_m=0;
for ir=1:size(WLGO_m,1)
    widthCurrent_m=WLGO_m(ir,1);
    lengthCurrent_m=WLGO_m(ir,2);
    endGapCurrent_m=WLGO_m(ir,3);
    edgeOffsetSpacingCurrent_m=WLGO_m(ir,4);
    if imag(edgeOffsetSpacingCurrent_m)~=0
        %Imaginary part of edgeOffset non zero: interpret the real part as
        %GAP between the long sides
        %edgeOffsetSpacingCurrent_m=OffsetFromEdge+j1;
        edgeOffsetSpacingCurrent_m=real(edgeOffsetSpacingCurrent_m)+widthCurrent_m/2+previouswidthCurrent_m/2;
    end
    lineNameStr=['Line' num2str(ir,'%03d')];
    csNameStr=['CS' lineNameStr];
    widthVar=[lineNameStr '_Wdt'];
    lengthVar=[lineNameStr '_Len' ];
    endGapVar=[lineNameStr '_Gap' ];
    edgeOffsetVar=[lineNameStr '_Off' ];
    hfsscreateVariableMm(oDesign,widthVar,widthCurrent_m);
    hfsscreateVariableMm(oDesign,lengthVar,lengthCurrent_m);
    hfsscreateVariableMm(oDesign,endGapVar,endGapCurrent_m);
    hfsscreateVariableMm(oDesign,edgeOffsetVar,edgeOffsetSpacingCurrent_m);
    colorStr=[255 128 64]; %light orange
    hfsscreateblock(oEditor,lineNameStr,metalName,endGapVar,[edgeOffsetVar '-' widthVar '/2'],0,lengthVar,widthVar,metalThicknessVar,csName,colorStr);
    hfsssetSolveInside(oEditor,lineNameStr,false);
    %Update the min and max extent
    xminmaxcurrent_str={endGapVar,[endGapVar '+' lengthVar]};
    if isempty(currentX_str)
        minXcurrent_str=['min(' xminmaxcurrent_str{1} ', '  xminmaxcurrent_str{2} ')'];
        maxXcurrent_str=['max(' xminmaxcurrent_str{1} ', ' xminmaxcurrent_str{2} ')'];
    else
        minXcurrent_str=['min(' currentX_str '+' xminmaxcurrent_str{1} ', '  currentX_str '+' xminmaxcurrent_str{2} ')'];
        maxXcurrent_str=['max(' currentX_str '+' xminmaxcurrent_str{1} ', '  currentX_str '+' xminmaxcurrent_str{2} ')'];
    end
    if isempty(minX_str)
        minX_str=minXcurrent_str;
    else
        minX_str=['min(' minX_str ',' minXcurrent_str ')'];
    end
    minX_m=min([minX_m,currentX_m+endGapCurrent_m,currentX_m+endGapCurrent_m+lengthCurrent_m]);
    if isempty(maxX_str)
        maxX_str=maxXcurrent_str;
    else
        maxX_str=['max(' maxX_str ',' maxXcurrent_str ')'];
    end    
    maxX_m=max([maxX_m,currentX_m+endGapCurrent_m,currentX_m+endGapCurrent_m+lengthCurrent_m]);
    yminmaxcurrent_str={[edgeOffsetVar '-' widthVar '/2'],[edgeOffsetVar '+' widthVar '/2']};
    if isempty(currentY_str)
        minYcurrent_str=['min(' yminmaxcurrent_str{1} ', '  yminmaxcurrent_str{2} ')'];
        maxYcurrent_str=['max(' yminmaxcurrent_str{1} ', '  yminmaxcurrent_str{2} ')'];
    else
        minYcurrent_str=['min(' currentY_str '+' yminmaxcurrent_str{1} ', '  currentY_str '+' yminmaxcurrent_str{2} ')'];
        maxYcurrent_str=['max(' currentY_str '+' yminmaxcurrent_str{1} ', '  currentY_str '+' yminmaxcurrent_str{2} ')'];
    end
    if isempty(minY_str)
        minY_str=minYcurrent_str;
    else
        minY_str=['min(' minY_str ',' minYcurrent_str ')'];
    end
    minY_m=min([minY_m,currentY_m+edgeOffsetSpacingCurrent_m-widthCurrent_m/2,currentY_m+edgeOffsetSpacingCurrent_m+widthCurrent_m/2]);
    if isempty(maxY_str)
        maxY_str=maxYcurrent_str;
    else
        maxY_str=['max(' maxY_str ',' maxYcurrent_str ')'];
    end    
    maxY_m=max([maxY_m,currentY_m+edgeOffsetSpacingCurrent_m-widthCurrent_m/2,currentY_m+edgeOffsetSpacingCurrent_m+widthCurrent_m/2]);
    %Update the expression of the current point X and Y
    currentX_m=currentX_m+endGapCurrent_m+lengthCurrent_m;
    currentcurrentX_str=[endGapVar '+' lengthVar];
    if isempty(currentX_str)
        currentX_str=currentcurrentX_str;
    else
        currentX_str=[currentX_str '+' currentcurrentX_str];
    end
    currentY_m=currentY_m+edgeOffsetSpacingCurrent_m;
    currentcurrentY_str=edgeOffsetVar;
    if isempty(currentY_str)
        currentY_str=currentcurrentY_str;
    else
        currentY_str=[currentY_str '+' currentcurrentY_str];
    end

    %Now create the coordinate system at the end
    oid=hfssgetObjectIDByName(oEditor,lineNameStr);
    if vers<2018
        %%In Ansys 2017 regardless of the active Coordinate system,
        %%getEdgeByPosition worked using global coordinates
        eid=hfssgetEdgeByPosition(oEditor,lineNameStr,currentX_m,currentY_m,(0));
    else
        %%In Ansys 2019 getEdgeByPosition works on the active coordinate
        %%system
        eid=hfssgetEdgeByPosition(oEditor,lineNameStr,endGapCurrent_m+lengthCurrent_m,edgeOffsetSpacingCurrent_m,(0));
    end
    %Create the new CS and forget the name of the previous
    csName=hfsscreateObjectCS(oEditor,oid,eid,csNameStr);  
    %Update the previous width, in case it is needed for an offset
    %specified between edges (instead than between centerlines)
    previouswidthCurrent_m=widthCurrent_m;
end

%Create Substrate and ground
xMinVar='_xMin';
hfsscreateVariableMm(oDesign,xMinVar,minX_str);
xMaxVar='_xMax';
hfsscreateVariableMm(oDesign,xMaxVar,maxX_str);
yMinVar='_yMin';
hfsscreateVariableMm(oDesign,yMinVar,minY_str);
yMaxVar='_yMax';
hfsscreateVariableMm(oDesign,yMaxVar,maxY_str);
substrateThicknessVar='_subsThick';
hfsscreateVariableMm(oDesign,substrateThicknessVar,subsH_m);
substrateBorderYMinVar='_borderYMin';
substrateBorderYMaxVar='_borderYMax';
hfsscreateVariableMm(oDesign,substrateBorderYMinVar,borderYMin_m);
hfsscreateVariableMm(oDesign,substrateBorderYMaxVar,borderYMax_m);
%Switch back to the global coordinate system
csName='Global';
hfsssetWCS(oEditor,'Global');
%Create the substrate
substrateBlockStr='Substrate';
hfsscreateblock(oEditor,substrateBlockStr,dielName,xMinVar,[yMinVar '-' substrateBorderYMinVar],0,[xMaxVar '-' xMinVar],[yMaxVar '-' yMinVar '+' substrateBorderYMinVar '+' substrateBorderYMaxVar],['-' substrateThicknessVar],csName);
%Create ground below substrate
gndBlockStr='Gnd';
colorStr=[64 0 0]; %Brown
hfsscreateblock(oEditor,gndBlockStr,metalName,xMinVar,[yMinVar '-' substrateBorderYMinVar],['-' substrateThicknessVar],[xMaxVar '-' xMinVar],[yMaxVar '-' yMinVar '+' substrateBorderYMinVar '+' substrateBorderYMaxVar],[ '-' metalThicknessVar ],csName,colorStr);
hfsssetSolveInside(oEditor,gndBlockStr,false);
%BY DEFAULT THERE IS A PEC BELOW GND! Losses would need a further air layer
%below (TODO, NOT YET IMPLEMENTED)

%Create air: 
airBlockStr='Airbox';
airDielName='Vacuum';
airThicknessVar='_Air';
hfsscreateVariableMm(oDesign,airThicknessVar,airThick_m);
%version 1 with same size as substrate (heavy variable computation)
colorStr=[128 255 255]; %Light blue
hfsscreateblock(oEditor,airBlockStr,airDielName,xMinVar,[yMinVar '-' substrateBorderYMinVar],0,[xMaxVar '-' xMinVar],[yMaxVar '-' yMinVar '+' substrateBorderYMinVar '+' substrateBorderYMaxVar],airThicknessVar,csName,colorStr);
%%%%Version 2: extrude the top face of the substrate NOT WORKING
%%substratetopfaceid=hfssgetFaceByPosition(oEditor,substrateBlockStr,(maxX_m+minX_m)/2,(maxY_m+minY_m)/2,0);
%%hfsssweepface(oEditor,substrateBlockStr,substratetopfaceid,airThicknessVar,airBlockStr);
%%hfssassignmaterial(oEditor,airBlockStr,airDielName);
hfsschangeColor(oEditor,airBlockStr,colorStr,0.9,true); %Set to wireframe and transparent
%Set radiation boundaries on air (except zmin)
[facexmin,facexmax,faceymin,faceymax,facezmin,facezmax]=hfssgetOrientedFaces(oEditor,airBlockStr);
hfssassignRadiationFaces(oDesign,[facexmin,facexmax,faceymin,faceymax,facezmax],'RadBoundaryOnAir');

%Create port1 at X=0 and centered around Y=0
portWidthVar='_PortWidth';
hfsscreateVariableMm(oDesign,portWidthVar,portwidth_m);
portHeightAboveVar='_PortHeigthAbove';
hfsscreateVariableMm(oDesign,portHeightAboveVar,portheightabove);
port1NameStr='P1';
hfsscreaterectangle(oEditor,port1NameStr,0,['-' portWidthVar '/2'],['-' substrateThicknessVar '-' metalThicknessVar],portWidthVar,[substrateThicknessVar '+' metalThicknessVar '+' portHeightAboveVar],'X');
colorStr=[128 255 255]; %Light blue
hfsschangeColor(oEditor,port1NameStr,colorStr,0.5,false); %Set slightly transparent
portface=hfssgetFaceIDsFromModel(oEditor,port1NameStr);
port1Name='Port1';
deembedPort_m=0;
portfaceid=str2num(portface{1});
%Integration lines cannot use variables
%hfssassignWavePortSingleMode(oDesign,portfaceid,port1Name,0,0,['-' substrateThicknessVar],0,0,0,deembedPort_m);%Integration line in global coordinates
%The integration line is set from the bottom edge of the port to the upper
%edge of the line. 
%The obvious alternative would be to have the line to go from the top edge
%of ground to the bottom edge of the line, but doing so makes the line
%"connected" to the substrate and thus changing the y limits would destroy
%the integration line
hfssassignWavePortSingleMode(oDesign,portfaceid,port1Name,0,0,-subsH_m-metalThick_m,0,0,metalThick_m,deembedPort_m);%Integration line in global coordinates
%Create port2  at currentX and centered around currentY
port2NameStr='P2';
hfsscreaterectangle(oEditor,port2NameStr,currentX_str,[currentY_str '-(' portWidthVar '/2)'],['-' substrateThicknessVar '-' metalThicknessVar],portWidthVar,[substrateThicknessVar '+' metalThicknessVar '+' portHeightAboveVar],'X');
hfsschangeColor(oEditor,port2NameStr,colorStr,0.5,false); %Set slightly transparent
portface=hfssgetFaceIDsFromModel(oEditor,port2NameStr);
port2Name='Port2';
deembedPort_m=0;
portfaceid=str2num(portface{1});
%hfssassignWavePortSingleMode(oDesign,portfaceid,port2Name,currentX_str,currentY_str,['-' substrateThicknessVar],currentX_str,currentY_str,0,deembedPort_m);%Integration line in global coordinates
hfssassignWavePortSingleMode(oDesign,portfaceid,port2Name,currentX_m,currentY_m,-subsH_m-metalThick_m,currentX_m,currentY_m,metalThick_m,deembedPort_m);%Integration line in global coordinates

%Setup simulation
hfsssetAnalysis(oDesign,frequencyCenter_Hz,frequencyCenter_Hz-frequencySpan_Hz/2,frequencyCenter_Hz+frequencySpan_Hz/2,maxDeltaS,Nfreqpoints,false,false);
hfsssetReports(oDesign);